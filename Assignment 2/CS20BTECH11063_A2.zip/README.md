# Data Structures Assignment 2
### Tanmay Garg CS20BTECH11063

To Run the Program enter the following command in the terminal or powershell window:

```
$ gcc *.c *.h -o main
$ ./main
```