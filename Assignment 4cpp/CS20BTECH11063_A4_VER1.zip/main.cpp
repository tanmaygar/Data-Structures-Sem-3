#include <iostream>
#include <vector>
#include <algorithm>
#include <array>
#include <list>
#include "minheaps.h"
#include "graphs.h"

int main()
{
    // std::vector<class time_stamp_event> HeapArray;
    // class node_persons np(1, SUS);
    // class time_stamp_event t1(2, INF, &np);
    // class time_stamp_event t2(3, INF, &np);
    // class time_stamp_event t3(3, REC, &np);
    // class time_stamp_event t4(1, INF, &np);

    // insertHeap(HeapArray, t1);
    // insertHeap(HeapArray, t2);
    // insertHeap(HeapArray, t3);
    // insertHeap(HeapArray, t4);

    // deleteMinHeap(HeapArray);

    // printHeap(HeapArray);

    class Graph PandemicGraph;
    std::vector<class time_stamp_event> TSE_HeapArray;
    std::srand(std::time(NULL));
    PandemicGraph.CreateEdges();
    PandemicGraph.RunPandemicSimulator(TSE_HeapArray);
    
    return EXIT_SUCCESS;
}